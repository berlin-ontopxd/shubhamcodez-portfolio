# ShubhamCodez — Code, Verse & Cosmos

A responsive, single-page personal portfolio for Shubham Kashyap Jena. Built with HTML, CSS, and vanilla JavaScript; no build step is required.

## Sections
- About
- Projects (Orchestra and Sugam IRCTC placeholders)
- Research
- MUN and other achievements
- Interdisciplinary interests
- Languages
- Social links

## Run locally
Open `index.html` in your browser, or run a simple local server:

```bash
python3 -m http.server 8000
```

Then visit http://localhost:8000.

## Deploy to Netlify
1. Push these files to a GitHub repository (for example `shubhamcodez-portfolio`).
2. In Netlify, select **Add new project → Import an existing project**.
3. Connect GitHub and choose the repository.
4. For this plain HTML site, set the publish directory to `.` and leave the build command empty.
5. Deploy and test the generated `*.netlify.app` URL before assigning your custom domain.

You can also use Netlify Drop to preview by uploading the extracted folder while signed into Netlify.

## Before publishing — personalise these items
- Replace the generic social profile URLs in `index.html` with the exact URLs from your Carrd page.
- Replace the GitHub links with your actual Orchestra and Sugam repository URLs.
- Verify award names, event names, dates, committee names, and recognition wording.
- Add direct links to real publications only after confirming publication status.
- Remove any section or detail you don't want public.
- Do not add API keys, passwords, tokens, private documents, personal phone numbers, or home address to a public repository.

## Domain migration safety
Do not delete the old Sugam Netlify site first. Deploy and test this portfolio as a separate Netlify project. Keep a backup of Sugam's source and note its deploy settings. Then in Netlify, remove `shubhamcodez.space` from the old site's **Domain management** and add it to the new portfolio site's **Domain management → Production domains**. Follow Netlify's prompts. If DNS is managed outside Netlify, do not alter DNS records unless Netlify's domain setup specifically asks you to. Check other DNS records (mail, verification, subdomains) before making changes.

Official documentation:
- https://docs.netlify.com/start/quickstarts/deploy-from-repository/
- https://docs.netlify.com/manage/domains/manage-domains/assign-a-domain-to-your-site-app/
