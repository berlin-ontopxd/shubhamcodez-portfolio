# ShubhamCodez — Academic Portfolio

A responsive, dark-academia-inspired personal portfolio built with HTML, CSS, and vanilla JavaScript.

## Features
- Editorial typography, navy/ivory/gold palette
- Animated orbital hero illustration and scroll reveal
- Responsive mobile navigation
- Reading progress indicator
- Reduced-motion accessibility support
- SEO and social preview metadata
- Clickable social profile cards
- Featured Sugam IRCTC source repository link

## Deploy to Netlify
1. Push these files to the `main` branch of `berlin-ontopxd/shubhamcodez-portfolio`.
2. In Netlify, choose **Add new project → Import an existing project**.
3. Select the portfolio repository.
4. Leave build command blank and use `.` as publish directory, unless you add a build system later.
5. Deploy and test the temporary `.netlify.app` URL before attaching `shubhamcodez.space`.

## Before going live
- Verify all social URLs and remove any profiles you do not want public.
- Add the direct Orchestra repository URL when known.
- Verify all award details and edit any wording that is inaccurate.
- Add verified publication titles/links rather than claiming unverified publication status.
- The Tesla quotation is commonly attributed to Nikola Tesla's 1919 autobiography, *My Inventions*; verify preferred punctuation/source if formal citation is required.

## Files
- `index.html` — content and page structure
- `styles.css` — visual design, animations, responsive layout
- `script.js` — menu, scroll progress, reveal animations
- `assets/favicon.svg` — favicon
